<?php
include_once('header.php');
?>

<div class="page">
    <div class="post-list">
        <?php
        if (have_posts()) {
            while (have_posts()) {
                the_post();
        ?>
                <div class="post-container">
                    <?php
                    $img = get_the_post_thumbnail_url();
                    if ($img !== false) {
                    ?>
                        <img src="<?php echo $img; ?>" />
                    <?php } ?>
                    <div class="post-content">
                        <h2><?php the_title() ?></h2>
                        <p><?php the_excerpt(); ?></p>
                    </div>
                </div>
        <?php
            }
        } ?>
    </div>
</div>

<?php include_once('footer.php'); ?>