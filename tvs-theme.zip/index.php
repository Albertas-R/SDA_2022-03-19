<?php include_once('header.php'); ?>
index
<?php include_once('footer.php'); ?>