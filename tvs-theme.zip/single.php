<?php include_once('header.php'); ?>

<div class="page">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

            <div class="">
                <?php
                $img = get_the_post_thumbnail_url();
                if ($img !== false) {
                ?>
                    <img src="<?php echo $img; ?>" />
                <?php } ?>
                <div class="">
                    <h2><?php the_title() ?></h2>
                    <p><?php the_excerpt(); ?></p>
                </div>

                <?php echo CFS()->get('kaina'); ?>
            </div>
    <?php
        endwhile;
    endif;
    ?>
</div>
<?php include_once('footer.php'); ?>