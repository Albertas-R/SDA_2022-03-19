<?php
// Template Name: Front Page

include_once('header.php');
?>

<div class="page">
  Front
</div>

<?php include_once('footer.php'); ?>