<!DOCTYPE html>
<html>

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <title><?php bloginfo('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <?php wp_head(); ?>
</head>

<body>
    <div class="site-container">
        <header class="main-header">
            <?php
            wp_nav_menu(
                array(
                    "menu" => "top-menu",
                    "menu_class" => "top-navigation",
                    "container" => null
                )
            )
            ?>
        </header>

        <section class="content">