</section>

<footer class="main-footer">
    <?php
    wp_nav_menu(
        array(
            "menu" => "bottom-menu",
            "menu_class" => "bottom-navigation",
            "container" => null
        )
    )
    ?>
</footer>
</div>
</body>

</html>